import React from "react";
import "./style.css";
import HotelHeader from './Component/HotelHeader';
import HotelSlider from './Component/HotelSlider';
import HotelBlog from './Component/HotelBlog';
import HotelRoomsBlog from './Component/HotelRoomsBlog';
import HotelFooter from './Component/HotelFooter';

function App() {
  return (
    <div className="App">
      <>
        <HotelHeader/>
        <HotelSlider/>
        <HotelBlog/>
        <HotelRoomsBlog/>
        <HotelFooter/>
      </>
    </div>
  );
}

export default App;