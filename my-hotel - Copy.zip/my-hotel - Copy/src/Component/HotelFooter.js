import React from 'react';
import { FaHotel, FaPhone, FaEnvelope, FaMapMarkerAlt, FaFacebook, FaTwitter, FaInstagram, FaTripadvisor, FaYoutube } from 'react-icons/fa';
import { MdRestaurant, MdSpa, MdLocalOffer, MdPool } from 'react-icons/md';
import './HotelFooter.css';

const HotelFooter = () => {
  return (
    <footer className="hotel-footer">
      {/* Main Footer Content */}
      <div className="footer-main">
        <div className="container">
          <div className="footer-grid">
            
            {/* About Section */}
            <div className="footer-section about-section">
              <div className="footer-logo">
                <FaHotel className="logo-icon" />
                <div className="logo-text">
                  <h3>Grand Horizon</h3>
                  <p>Luxury Hotels & Resorts</p>
                </div>
              </div>
              <p className="about-text">
                Experience unparalleled luxury at Grand Horizon, where world-class amenities meet breathtaking views. 
                Our 5-star resort offers unforgettable experiences for leisure and business travelers alike.
              </p>
              <div className="footer-social">
                <a href="#" aria-label="Facebook"><FaFacebook /></a>
                <a href="#" aria-label="Twitter"><FaTwitter /></a>
                <a href="#" aria-label="Instagram"><FaInstagram /></a>
                <a href="#" aria-label="TripAdvisor"><FaTripadvisor /></a>
                <a href="#" aria-label="YouTube"><FaYoutube /></a>
              </div>
            </div>
            
            {/* Quick Links */}
            <div className="footer-section links-section">
              <h4 className="footer-title">Quick Links</h4>
              <ul className="footer-links">
                <li><a href="#"><FaHotel /> Home</a></li>
                <li><a href="#"><MdRestaurant /> Dining</a></li>
                <li><a href="#"><MdSpa /> Spa & Wellness</a></li>
                <li><a href="#"><MdPool /> Pool & Recreation</a></li>
                <li><a href="#"><MdLocalOffer /> Special Offers</a></li>
              </ul>
            </div>
            
            {/* Contact Info */}
            <div className="footer-section contact-section">
              <h4 className="footer-title">Contact Us</h4>
              <ul className="contact-info">
                <li>
                  <FaMapMarkerAlt className="contact-icon" />
                  <span>123 Ocean Boulevard, Goa, India - 403512</span>
                </li>
                <li>
                  <FaPhone className="contact-icon" />
                  <span>+91 98765 43210</span>
                </li>
                <li>
                  <FaEnvelope className="contact-icon" />
                  <span>reservations@grandhorizon.com</span>
                </li>
              </ul>
              
              <div className="newsletter">
                <h5>Subscribe to Newsletter</h5>
                <div className="newsletter-input">
                  <input type="email" placeholder="Your email address" />
                  <button>Subscribe</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Footer Bottom */}
      <div className="footer-bottom">
        <div className="container">
          <div className="bottom-content">
            <p>&copy; {new Date().getFullYear()} Grand Horizon Hotels & Resorts. All Rights Reserved.</p>
            <div className="legal-links">
              <a href="#">Privacy Policy</a>
              <a href="#">Terms of Service</a>
              <a href="#">Sitemap</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default HotelFooter;