import React, { useState, useEffect } from 'react';
import { FaHotel, FaSearch, FaUser, FaPhone, FaCalendarAlt, FaBars, FaTimes } from 'react-icons/fa';
import { MdRestaurant, MdSpa, MdLocalOffer } from 'react-icons/md';
import { IoMdContacts } from 'react-icons/io';
import './HotelHeader.css';

const HotelHeader = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleDropdown = (dropdown) => {
    setActiveDropdown(activeDropdown === dropdown ? null : dropdown);
  };

  return (
    <>
      {/* Top Announcement Bar */}
      <div className="announcement-bar">
        <div className="container">
          <div className="announcement-content">
            <div className="contact-info">
              <span><FaPhone /> +91 98765 43210</span>
              <span className="badge">5-Star Luxury Resort</span>
            </div>
            <div className="auth-buttons">
              <button className="btn-login"><FaUser /> Login</button>
              <button className="btn-primary"><FaCalendarAlt /> Book Now</button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className={`main-header ${isScrolled ? 'scrolled' : ''}`}>
        <div className="container">
          <div className="header-content">
            {/* Logo */}
            <a href="/" className="brand-logo">
              <div className="logo-icon">
                <FaHotel />
              </div>
              <div className="logo-text">
                <h1>Grand Horizon</h1>
                <p>Hotels & Resorts</p>
              </div>
            </a>

            {/* Desktop Navigation */}
            <nav className="desktop-nav">
              <ul className="nav-list">
                <li 
                  className={`nav-item ${activeDropdown === 'rooms' ? 'active' : ''}`}
                  onMouseEnter={() => toggleDropdown('rooms')}
                  onMouseLeave={() => toggleDropdown('rooms')}
                >
                  <button className="nav-link">
                    Rooms & Suites
                    <span className="dropdown-arrow">▼</span>
                  </button>
                  <div className="dropdown-menu">
                    <a href="#">Deluxe Room</a>
                    <a href="#">Executive Suite</a>
                    <a href="#">Presidential Suite</a>
                    <a href="#">Family Room</a>
                  </div>
                </li>
                <li className="nav-item">
                  <a href="#" className="nav-link"><MdRestaurant /> Dining</a>
                </li>
                <li className="nav-item">
                  <a href="#" className="nav-link"><MdSpa /> Spa</a>
                </li>
                <li className="nav-item">
                  <a href="#" className="nav-link"><MdLocalOffer /> Offers</a>
                </li>
                <li className="nav-item">
                  <a href="#" className="nav-link"><IoMdContacts /> Contact</a>
                </li>
              </ul>
            </nav>

            {/* Mobile Menu Toggle */}
            <button 
              className="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <FaTimes /> : <FaBars />}
            </button>

            {/* Search and Actions */}
            <div className="header-actions">
              <div className="search-box">
                <FaSearch className="search-icon" />
                <input type="text" placeholder="Search..." />
              </div>
              <button className="btn-primary">Book Now</button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        <div className={`mobile-nav ${mobileMenuOpen ? 'open' : ''}`}>
          <div className="mobile-search">
            <FaSearch />
            <input type="text" placeholder="Search..." />
          </div>
          <ul className="mobile-nav-list">
            <li className="mobile-nav-item">
              <button 
                className="mobile-nav-link"
                onClick={() => toggleDropdown('mobileRooms')}
              >
                Rooms & Suites
                <span className={`dropdown-arrow ${activeDropdown === 'mobileRooms' ? 'up' : ''}`}>▼</span>
              </button>
              <div className={`mobile-dropdown ${activeDropdown === 'mobileRooms' ? 'show' : ''}`}>
                <a href="#">Deluxe Room</a>
                <a href="#">Executive Suite</a>
                <a href="#">Presidential Suite</a>
              </div>
            </li>
            <li className="mobile-nav-item"><a href="#" className="mobile-nav-link"><MdRestaurant /> Dining</a></li>
            <li className="mobile-nav-item"><a href="#" className="mobile-nav-link"><MdSpa /> Spa</a></li>
            <li className="mobile-nav-item"><a href="#" className="mobile-nav-link"><MdLocalOffer /> Offers</a></li>
            <li className="mobile-nav-item"><a href="#" className="mobile-nav-link"><IoMdContacts /> Contact</a></li>
          </ul>
        </div>
      </header>
    </>
  );
};

export default HotelHeader;