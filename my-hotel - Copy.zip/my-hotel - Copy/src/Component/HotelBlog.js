import React from 'react';
import { FaStar, FaMapMarkerAlt, FaPhone, FaEnvelope, FaWifi, FaSwimmingPool, FaParking, FaUtensils } from 'react-icons/fa';
import './HotelBlog.css';

const HotelBlog = () => {
  return (
    <div className="hotel-blog-section">
      <div className="container">
        <h2 className="section-title">Welcome to <span>Grand Horizon</span></h2>
        <p className="section-subtitle">5-Star Luxury Resort & Spa</p>
        
        <div className="blog-content">
          {/* Hotel Image */}
          <div className="hotel-image-container">
            <div className="image-wrapper">
              <img 
                src="https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3" 
                alt="Grand Horizon Resort" 
                className="hotel-image"
              />
              <div className="image-overlay">
                <div className="rating-badge">
                  <FaStar className="star-icon" />
                  <span>5.0 (1200+ Reviews)</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Hotel Description */}
          <div className="hotel-description">
            <h3>Experience Unparalleled Luxury</h3>
            <p>
              Nestled along the pristine coastline, Grand Horizon offers breathtaking ocean views 
              and world-class amenities. Our resort combines contemporary elegance with traditional 
              hospitality to create unforgettable experiences.
            </p>
            
            <div className="highlight-features">
              <div className="feature-item">
                <FaWifi className="feature-icon" />
                <span>Free High-Speed WiFi</span>
              </div>
              <div className="feature-item">
                <FaSwimmingPool className="feature-icon" />
                <span>Infinity Pool</span>
              </div>
              <div className="feature-item">
                <FaParking className="feature-icon" />
                <span>Valet Parking</span>
              </div>
              <div className="feature-item">
                <FaUtensils className="feature-icon" />
                <span>3 Gourmet Restaurants</span>
              </div>
            </div>
            
            <div className="hotel-details">
              <div className="detail-item">
                <FaMapMarkerAlt className="detail-icon" />
                <span>123 Ocean Boulevard, Goa, India</span>
              </div>
              <div className="detail-item">
                <FaPhone className="detail-icon" />
                <span>+91 98765 43210</span>
              </div>
              <div className="detail-item">
                <FaEnvelope className="detail-icon" />
                <span>reservations@grandhorizon.com</span>
              </div>
            </div>
            
            <button className="explore-btn">Explore Our Rooms</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HotelBlog;