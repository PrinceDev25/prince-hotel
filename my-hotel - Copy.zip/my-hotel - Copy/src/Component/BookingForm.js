import React, { useState } from 'react';
import { FaCalendarAlt, FaUser, FaBed, FaPhone, FaEnvelope, FaChevronDown } from 'react-icons/fa';
import { MdMeetingRoom, MdChildCare, MdStars } from 'react-icons/md';
import { IoIosArrowForward } from 'react-icons/io';
import './BookingForm.css';

const BookingForm = () => {
  const [formData, setFormData] = useState({
    checkIn: '',
    checkOut: '',
    adults: 2,
    children: 0,
    roomType: 'deluxe',
    name: '',
    email: '',
    phone: '',
    specialRequests: '',
    promoCode: ''
  });

  const [activeSection, setActiveSection] = useState('dates');
  const [showRoomDetails, setShowRoomDetails] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Booking submitted:', formData);
    alert('Your booking request has been received! Our team will contact you shortly to confirm.');
  };

  const roomTypes = [
    { 
      value: 'deluxe', 
      label: 'Deluxe Ocean View', 
      price: '$299/night',
      description: 'Spacious room with king bed and private balcony overlooking the ocean',
      amenities: ['Free WiFi', 'Breakfast included', '40 sqm', 'Ocean view']
    },
    { 
      value: 'executive', 
      label: 'Executive Suite', 
      price: '$499/night',
      description: 'Luxurious suite with separate living area and premium amenities',
      amenities: ['Free WiFi', 'Breakfast included', 'Executive lounge access', '65 sqm']
    },
    { 
      value: 'presidential', 
      label: 'Presidential Suite', 
      price: '$899/night',
      description: 'Ultimate luxury with expansive space and personalized butler service',
      amenities: ['Butler service', 'Jacuzzi', 'Private dining', '120 sqm']
    },
    { 
      value: 'family', 
      label: 'Family Suite', 
      price: '$599/night',
      description: 'Perfect for families with connected rooms and child-friendly amenities',
      amenities: ['Connecting rooms', 'Kids club access', 'Childcare services', '80 sqm']
    }
  ];

  const navigateSection = (section) => {
    setActiveSection(section);
    window.scrollTo({
      top: document.getElementById(section).offsetTop - 20,
      behavior: 'smooth'
    });
  };

  return (
    <div className="booking-form-container">
      <div className="form-header">
        <h2>Reserve Your Luxury Stay</h2>
        <p>Complete just a few details to secure your perfect getaway at Grand Horizon</p>
      </div>

      {/* Progress Indicator */}
      <div className="booking-progress">
        <button 
          className={`progress-step ${activeSection === 'dates' ? 'active' : ''}`}
          onClick={() => navigateSection('dates')}
        >
          <span>1</span> Dates
        </button>
        <IoIosArrowForward className="progress-arrow" />
        <button 
          className={`progress-step ${activeSection === 'guests' ? 'active' : ''}`}
          onClick={() => navigateSection('guests')}
        >
          <span>2</span> Guests
        </button>
        <IoIosArrowForward className="progress-arrow" />
        <button 
          className={`progress-step ${activeSection === 'room' ? 'active' : ''}`}
          onClick={() => navigateSection('room')}
        >
          <span>3</span> Room
        </button>
        <IoIosArrowForward className="progress-arrow" />
        <button 
          className={`progress-step ${activeSection === 'personal' ? 'active' : ''}`}
          onClick={() => navigateSection('personal')}
        >
          <span>4</span> Details
        </button>
      </div>

      <form onSubmit={handleSubmit} className="booking-form">
        {/* Dates Section */}
        <div id="dates" className="form-section">
          <h3><FaCalendarAlt className="section-icon" /> Select Your Dates</h3>
          <div className="date-fields">
            <div className="form-group">
              <div className="input-with-icon">
                <label htmlFor="checkIn">Check-In Date</label>
                <input
                  type="date"
                  id="checkIn"
                  name="checkIn"
                  value={formData.checkIn}
                  onChange={handleChange}
                  required
                />
                <FaCalendarAlt className="input-icon" />
              </div>
            </div>
            
            <div className="form-group">
              <div className="input-with-icon">
                <label htmlFor="checkOut">Check-Out Date</label>
                <input
                  type="date"
                  id="checkOut"
                  name="checkOut"
                  value={formData.checkOut}
                  onChange={handleChange}
                  required
                />
                <FaCalendarAlt className="input-icon" />
              </div>
            </div>
          </div>
        </div>

        {/* Guests Section */}
        <div id="guests" className="form-section">
          <h3><FaUser className="section-icon" /> Guest Information</h3>
          <div className="guest-fields">
            <div className="form-group">
              <label htmlFor="adults">Adults</label>
              <div className="select-wrapper">
                <select
                  id="adults"
                  name="adults"
                  value={formData.adults}
                  onChange={handleChange}
                >
                  {[1, 2, 3, 4, 5].map(num => (
                    <option key={num} value={num}>{num} {num === 1 ? 'Adult' : 'Adults'}</option>
                  ))}
                </select>
                <FaChevronDown className="select-arrow" />
              </div>
            </div>
            
            <div className="form-group">
              <label htmlFor="children">Children</label>
              <div className="select-wrapper">
                <select
                  id="children"
                  name="children"
                  value={formData.children}
                  onChange={handleChange}
                >
                  {[0, 1, 2, 3, 4].map(num => (
                    <option key={num} value={num}>{num} {num === 1 ? 'Child' : 'Children'}</option>
                  ))}
                </select>
                <FaChevronDown className="select-arrow" />
              </div>
            </div>
          </div>
        </div>

        {/* Room Selection */}
        <div id="room" className="form-section">
          <h3><MdMeetingRoom className="section-icon" /> Choose Your Room</h3>
          <div className="room-options">
            {roomTypes.map(room => (
              <div key={room.value} className="room-option">
                <input
                  type="radio"
                  id={room.value}
                  name="roomType"
                  value={room.value}
                  checked={formData.roomType === room.value}
                  onChange={handleChange}
                />
                <label htmlFor={room.value}>
                  <div className="room-header">
                    <div className="room-icon">
                      <FaBed />
                    </div>
                    <div className="room-info">
                      <h4>{room.label}</h4>
                      <p className="room-price">{room.price}</p>
                    </div>
                  </div>
                  <button 
                    type="button"
                    className="room-details-toggle"
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowRoomDetails(showRoomDetails === room.value ? null : room.value);
                    }}
                  >
                    {showRoomDetails === room.value ? 'Hide Details' : 'View Details'}
                  </button>
                  {showRoomDetails === room.value && (
                    <div className="room-details">
                      <p>{room.description}</p>
                      <div className="room-amenities">
                        {room.amenities.map((amenity, index) => (
                          <span key={index} className="amenity-badge">{amenity}</span>
                        ))}
                      </div>
                    </div>
                  )}
                </label>
              </div>
            ))}
          </div>
        </div>

        {/* Personal Information */}
        <div id="personal" className="form-section">
          <h3>Personal Details</h3>
          <div className="personal-fields">
            <div className="form-group">
              <label htmlFor="name">Full Name</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="As it appears on ID"
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="email">Email Address</label>
              <div className="input-with-icon">
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  placeholder="Your confirmation will be sent here"
                />
                <FaEnvelope className="input-icon" />
              </div>
            </div>
            
            <div className="form-group">
              <label htmlFor="phone">Phone Number</label>
              <div className="input-with-icon">
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                  placeholder="For booking confirmation"
                />
                <FaPhone className="input-icon" />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="promoCode">Promo Code (Optional)</label>
              <div className="input-with-icon">
                <input
                  type="text"
                  id="promoCode"
                  name="promoCode"
                  value={formData.promoCode}
                  onChange={handleChange}
                  placeholder="Enter discount code if available"
                />
                <MdStars className="input-icon" />
              </div>
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="specialRequests">Special Requests</label>
            <textarea
              id="specialRequests"
              name="specialRequests"
              value={formData.specialRequests}
              onChange={handleChange}
              placeholder="Please let us know if you have any special requirements (dietary needs, accessibility, celebrations, etc.)"
              rows="4"
            ></textarea>
          </div>
        </div>

        <div className="form-submit">
          <div className="booking-summary">
            <h4>Your Booking Summary</h4>
            <div className="summary-details">
              <div className="summary-item">
                <span>Room Type:</span>
                <span>{roomTypes.find(r => r.value === formData.roomType)?.label}</span>
              </div>
              <div className="summary-item">
                <span>Guests:</span>
                <span>{formData.adults} {formData.adults === 1 ? 'Adult' : 'Adults'}{formData.children > 0 ? `, ${formData.children} ${formData.children === 1 ? 'Child' : 'Children'}` : ''}</span>
              </div>
              {formData.checkIn && (
                <div className="summary-item">
                  <span>Dates:</span>
                  <span>
                    {new Date(formData.checkIn).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - {new Date(formData.checkOut).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </span>
                </div>
              )}
            </div>
          </div>

          <div className="submit-container">
            <button type="submit" className="submit-btn">
              Complete Reservation
            </button>
            <p className="secure-booking">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="#b8860b">
                <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11V11.99z"/>
              </svg>
              Secure SSL Encryption • No credit card required to book
            </p>
          </div>
        </div>
      </form>
    </div>
  );
};

export default BookingForm;