import React, { useState, useEffect } from 'react';
import { FaChevronLeft, FaChevronRight, FaStar, FaWifi, FaSwimmingPool, FaParking, FaUtensils, FaConciergeBell } from 'react-icons/fa';
import { MdAcUnit, MdBeachAccess, MdFamilyRestroom } from 'react-icons/md';
import './HotelSlider.css';

const HotelSlider = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const slides = [
    {
      id: 1,
      image: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?ixlib=rb-4.0.3',
      title: 'Luxury Ocean View Suite',
      description: 'Experience breathtaking ocean views from your private balcony in our premium suite',
      price: '$399/night',
      features: ['Free WiFi', 'Breakfast Included', 'Private Beach Access']
    },
    {
      id: 2,
      image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3',
      title: 'Presidential Royal Suite',
      description: 'Ultimate luxury with separate living area, jacuzzi and 24/7 butler service',
      price: '$899/night',
      features: ['Butler Service', 'Jacuzzi', 'Lounge Area']
    },
    {
      id: 3,
      image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?ixlib=rb-4.0.3',
      title: 'Family Deluxe Package',
      description: 'Spacious rooms perfect for families with special amenities for children',
      price: '$599/night',
      features: ['Family Room', 'Kids Club Access', 'Connected Rooms']
    }
  ];

  const amenities = [
    { icon: <FaWifi />, name: 'Free WiFi' },
    { icon: <MdAcUnit />, name: 'AC' },
    { icon: <FaSwimmingPool />, name: 'Pool' },
    { icon: <FaParking />, name: 'Parking' },
    { icon: <FaUtensils />, name: 'Restaurant' },
    { icon: <FaConciergeBell />, name: '24/7 Service' },
    { icon: <MdBeachAccess />, name: 'Beach Access' },
    { icon: <MdFamilyRestroom />, name: 'Family Rooms' }
  ];

  // Auto-play functionality
  useEffect(() => {
    let interval;
    if (isAutoPlaying) {
      interval = setInterval(() => {
        setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [isAutoPlaying, slides.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  return (
    <div className="hotel-slider-container">
      {/* Main Slider */}
      <div className="slider-wrapper">
        {slides.map((slide, index) => (
          <div 
            key={slide.id}
            className={`slider-slide ${index === currentSlide ? 'active' : ''}`}
            style={{ backgroundImage: `url(${slide.image})` }}
          >
            <div className="slide-overlay"></div>
            <div className="slide-content">
              <div className="rating-badge">
                <FaStar className="star-icon" />
                <span>5.0 Luxury Resort</span>
              </div>
              <h2>{slide.title}</h2>
              <p>{slide.description}</p>
              <div className="price-tag">{slide.price}</div>
              <div className="slide-features">
                {slide.features.map((feature, i) => (
                  <span key={i} className="feature-badge">{feature}</span>
                ))}
              </div>
              <button className="book-now-btn">Book This Room</button>
            </div>
          </div>
        ))}

        {/* Navigation Arrows */}
        <button className="slider-arrow prev" onClick={prevSlide}>
          <FaChevronLeft />
        </button>
        <button className="slider-arrow next" onClick={nextSlide}>
          <FaChevronRight />
        </button>

        {/* Pagination Dots */}
        <div className="slider-dots">
          {slides.map((_, index) => (
            <button
              key={index}
              className={`dot ${index === currentSlide ? 'active' : ''}`}
              onClick={() => goToSlide(index)}
            />
          ))}
        </div>
      </div>

      {/* Amenities Bar */}
      <div className="amenities-bar">
        <div className="amenities-container">
          {amenities.map((amenity, index) => (
            <div key={index} className="amenity-item">
              <div className="amenity-icon">{amenity.icon}</div>
              <span>{amenity.name}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HotelSlider;