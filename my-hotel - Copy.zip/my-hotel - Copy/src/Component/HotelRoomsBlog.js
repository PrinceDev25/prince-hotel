import React from 'react';
import { FaStar, FaBed, FaRulerCombined, FaUser, FaSnowflake, FaWifi, FaTv, FaCoffee } from 'react-icons/fa';
import { MdBalcony, MdLocalBar, MdAcUnit } from 'react-icons/md';
import './HotelRoomsBlog.css';

const HotelRoomsBlog = () => {
  const rooms = [
    {
      id: 1,
      title: "Deluxe Ocean View Room",
      description: "Wake up to breathtaking ocean views from your private balcony in our spacious deluxe room.",
      image: "https://images.unsplash.com/photo-1596178065887-1198b6148b2b?ixlib=rb-4.0.3",
      price: "$299/night",
      size: "45 m²",
      capacity: "2 Adults",
      amenities: ["Ocean View", "Private Balcony", "King Bed", "Free WiFi"],
      rating: 4.8
    },
    {
      id: 2,
      title: "Executive Suite",
      description: "Luxurious suite with separate living area, perfect for business travelers or romantic getaways.",
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQwWVdDC8JiSfEDhJ0SNUMQ4lxHPhrjGoporg&s",
      price: "$499/night",
      size: "75 m²",
      capacity: "2 Adults + 1 Child",
      amenities: ["Living Area", "Mini Bar", "Work Desk", "Premium Amenities"],
      rating: 4.9
    },
    {
      id: 3,
      title: "Presidential Suite",
      description: "Ultimate luxury with expansive space, premium furnishings, and personalized butler service.",
      image: "https://images.unsplash.com/photo-1582719508461-905c673771fd?ixlib=rb-4.0.3",
      price: "$899/night",
      size: "120 m²",
      capacity: "4 Adults",
      amenities: ["Butler Service", "Jacuzzi", "Dining Area", "Panoramic Views"],
      rating: 5.0
    }
  ];

  const amenities = [
    { icon: <FaWifi />, name: "Free WiFi" },
    { icon: <MdAcUnit />, name: "AC" },
    { icon: <FaTv />, name: "Smart TV" },
    { icon: <FaCoffee />, name: "Coffee Maker" },
    { icon: <MdLocalBar />, name: "Mini Bar" },
    { icon: <FaSnowflake />, name: "Air Conditioning" }
  ];

  return (
    <div className="rooms-blog-section">
      <div className="container">
        <div className="section-header">
          <h2>Our <span>Luxurious</span> Accommodations</h2>
          <p>Experience unparalleled comfort in our carefully designed rooms and suites</p>
        </div>

        <div className="rooms-grid">
          {rooms.map(room => (
            <div key={room.id} className="room-card">
              <div className="room-image-container">
                <img src={room.image} alt={room.title} className="room-image" />
                <div className="room-badge">Bestseller</div>
                <div className="rating-badge">
                  <FaStar className="star-icon" />
                  <span>{room.rating}</span>
                </div>
              </div>
              
              <div className="room-content">
                <h3>{room.title}</h3>
                <p className="room-description">{room.description}</p>
                
                <div className="room-specs">
                  <div className="spec-item">
                    <FaRulerCombined className="spec-icon" />
                    <span>{room.size}</span>
                  </div>
                  <div className="spec-item">
                    <FaUser className="spec-icon" />
                    <span>{room.capacity}</span>
                  </div>
                  <div className="spec-item">
                    <FaBed className="spec-icon" />
                    <span>King Bed</span>
                  </div>
                </div>
                
                <div className="room-amenities">
                  {room.amenities.map((amenity, index) => (
                    <span key={index} className="amenity-tag">{amenity}</span>
                  ))}
                </div>
                
                <div className="room-footer">
                  <div className="room-price">{room.price}</div>
                  <button className="book-now-btn">Book Now</button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="amenities-section">
          <h3>Room Amenities</h3>
          <div className="amenities-grid">
            {amenities.map((amenity, index) => (
              <div key={index} className="amenity-item">
                <div className="amenity-icon">{amenity.icon}</div>
                <span>{amenity.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HotelRoomsBlog;